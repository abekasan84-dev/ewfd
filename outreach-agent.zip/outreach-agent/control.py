# Полная функция одного ответа. Проверка до отправки, не текст для человека.

RATES = ("1200", "1,200", "3000", "3,000", "5000", "5,000", "1500", "1,500")
FLATTERY = ("уникальн", "отличная возможность", "рад знаком", "huge fan", "love your", "exactly the kind")
PRESSURE = ("только сегодня", "мало мест", "last chance", "only today", "осталось мало")
ROLE_ASK = ("роль", "роли", "role", "roles", "其他", "ambassador", "ставк", "прайс", "all the")
_TZ_ASK = ("часовой пояс", "какой у тебя пояс", "timezone", "时区", "в каком ты часовом", "напиши, в каком")
_TZ_HAVE = ("пекин", "beijing", "北京", "варшав", "мск", "часовой пояс", "пояс")

def factor(burst: str) -> str:
    text = (burst or "").strip().lower()
    bare = "".join(ch for ch in text if ch not in " .!！。~～")
    if bare in {"收到", "收到了", "好", "好的", "行", "ok", "okay", "alright", "allright",
                "thanks", "谢谢", "嗯", "知道了", "got it", "noted", "yep", "yup",
                "sure", "cool", "fine", "yep", "yup", "got it", "noted"}:
        return "ack"
    if any(w in text for w in ("не пиши", "отписаться", "стоп", "stop", "unsubscribe")):
        return "refuse"
    if "?" in text or "？" in text or any(w in text for w in ("сколько", "how much", "什么", "吗", "есть ли", "можно")):
        return "question"
    if any(w in text for w in ("вечером", "晚上", "давай", "созвон", "十点", "завтра")):
        return "agree"
    return "talk"

def goal_for(kind: str) -> str:
    return {
        "ack": "silent",
        "refuse": "stop",
        "question": "answer",
        "agree": "confirm",
        "talk": "answer",
    }.get(kind, "answer")

def echoes_him(burst: str, draft: str) -> bool:
    def norm(s):
        s = (s or "").lower()
        for w in ("george", "andrew", "嗨", "hi", "hello"):
            s = s.replace(w, "")
        return "".join(ch for ch in s if ch.isalnum() or "\u4e00" <= ch <= "\u9fff")
    a, b = norm(burst), norm(draft)
    if len(a) < 24 or len(b) < 24:
        return False
    if a in b or b in a:
        return True
    from difflib import SequenceMatcher
    return SequenceMatcher(None, a, b).ratio() >= 0.72

def _rate_count(text: str) -> int:
    folded = text.replace(" ", "")
    return sum(1 for rate in RATES if rate.replace(" ", "") in folded or rate in text)

def errors(burst: str, draft: str, kind: str) -> list:
    text = draft or ""
    found = []
    if text.strip().upper() in {"SILENT", "SILENCE", "NONE"}:
        return found
    questions = text.count("?") + text.count("？")
    if questions > 1:
        found.append("два вопроса в одном сообщении")
    asked_roles = any(w in (burst or "").lower() for w in ROLE_ASK)
    if _rate_count(text) > 1 and not asked_roles:
        found.append("в одном сообщении больше одной ставки")
    if echoes_him(burst, text):
        found.append("скопировал его сообщение вместо ответа")
    low = text.lower()
    if any(w in low for w in ("感谢你的认可", "主动联系", "我很愿意了解", "thank you for reaching out", "thanks for reaching out")):
        found.append("ответил от его лица, а не от джорджа")
    if any(w in low for w in ("准备好付款", "准备付款", "你付款", "ready to pay", "are you ready to pay")):
        found.append("просит человека заплатить нам")
    if any(w in low for w in FLATTERY):
        found.append("лесть вместо ответа")
    if any(w in low for w in PRESSURE):
        found.append("давление сроком")
    burst_low = (burst or "").lower()
    if any(w in burst_low for w in _TZ_HAVE) and any(w in low for w in _TZ_ASK):
        found.append("переспрашивает пояс, который он уже назвал")
    if kind != "question" and len((burst or "").strip()) < 12 and len(text) > 220:
        found.append("слишком длинно на короткую реплику")
    return found

def review(burst: str, draft: str) -> dict:
    kind = factor(burst)
    goal = goal_for(kind)
    found = errors(burst, draft, kind)
    if goal == "silent" or "на подтверждение не отвечают" in found:
        action = "silent"
    elif found:
        action = "rewrite"
    else:
        action = "send"
    return {"factor": kind, "goal": goal, "errors": found, "action": action}

EXAMPLES = [
    {
        "name": "вопрос про базу",
        "burst": "按实际产出没有基础吗",
        "bad": "有基础。测试 1200 美元，社群 3000 美元。明天 22:00 或后天 22:00，你挑一个？",
        "good": "有基础。手机评测 1200 美元，测完手机留在你那里。",
    },
    {
        "name": "просто получил",
        "burst": "收到",
        "bad": "好，19号晚上十点见。",
        "good": "SILENT",
    },
    {
        "name": "один вопрос по-английски",
        "burst": "is there a base pay?",
        "bad": "Yes. Phone is $1,200 and community is $3,000. Can you do Tuesday, or is Wednesday better?",
        "good": "Yes. A phone review is $1,200, and you keep the phone.",
    },
]

def self_check() -> list:
    report = []
    for case in EXAMPLES:
        bad = review(case["burst"], case["bad"])
        good = review(case["burst"], case["good"])
        report.append({
            "name": case["name"],
            "bad_errors": bad["errors"],
            "bad_action": bad["action"],
            "good_action": good["action"],
            "ok": bad["action"] != "send" and good["action"] in {"send", "silent"},
        })
    return report
