# СБОРКА: телеграм-клиент, каденсер, входящие, роли, миссии, обучение,
# здоровье. Все фоновые петли под присмотром.

import asyncio, random, datetime as dt, logging, os, re
from telethon import TelegramClient, events
from telethon.errors import (
    FloodWaitError, UsernameInvalidError, UsernameNotOccupiedError, PeerIdInvalidError,
    PeerFloodError, UserPrivacyRestrictedError, ForbiddenError,
)

from telethon.tl.functions.channels import CreateChannelRequest, InviteToChannelRequest
from telethon.tl.functions.messages import ExportChatInviteRequest

import config, db, llm, playbook, roles, missions, learn, health, enrich, control

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
    handlers=[
        logging.FileHandler("bot.log", encoding="utf-8"),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("agent")

client = TelegramClient("session", config.API_ID, config.API_HASH)
PAUSED, BUSY = [], set()
ME_ID, FEWSHOT_CACHE = 0, []

READ_LAG = (18, 45); TYPE_CPS = 3.1 * 0.7; CHUNK = 900
PEER_GEN = {}
LAST_EVENT = {}

def call_slots() -> str:
    now = dt.datetime.now(dt.timezone(dt.timedelta(hours=2)))
    try:
        from zoneinfo import ZoneInfo
        now = dt.datetime.now(ZoneInfo("Europe/Warsaw"))
    except Exception:
        pass
    start = 0 if now.hour < 20 else 1
    days = [(now + dt.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(start, start + 3)]
    return (
        f"Сейчас у Джорджа {now.strftime('%Y-%m-%d %H:%M')} Europe/Warsaw. "
        f"Звонок только на эти даты: {', '.join(days)}. "
        "Спроси часовой пояс человека и назови два конкретных часа уже в его времени. "
        "Если пояс ещё не известен, предложи два часа по Варшаве и прямо скажи, что это Варшава. "
        "Не говори «на неделе» и не отправляй на пустой Calendly. "
        "Когда он выбрал — одной фразой зафиксируй день, число, час и чей это часовой пояс."
    )

def work_hours_ok():
    h = dt.datetime.now().hour
    return config.WH_START <= h < config.WH_END

def split_chunks(text, n=CHUNK):
    words,out,buf = text.split(),[],""
    for w in words:
        if len(buf)+len(w)+1 > n and buf: out.append(buf.strip()); buf=w
        else: buf += (" "+w)
    if buf.strip(): out.append(buf.strip())
    return out or [text]

def detect_lang(text: str) -> str:
    cyr = lat = cjk = 0
    for ch in (text or "").lower():
        if "а" <= ch <= "я" or ch == "ё":
            cyr += 1
        elif "a" <= ch <= "z":
            lat += 1
        elif "\u4e00" <= ch <= "\u9fff":
            cjk += 1
    if cjk >= 2 and cjk >= cyr and cjk >= lat:
        return "zh"
    if cyr == 0 and lat == 0:
        return ""
    return "ru" if cyr >= lat else "en"

def chat_lang(hist, burst: str) -> str:
    blob = " ".join((m.get("content") or m.get("text") or "") for m in (hist or [])[-10:])
    base = detect_lang(blob)
    last = detect_lang(burst)
    if base and len((burst or "").strip()) <= 40 and last != base:
        return base
    return last or base

def breaks_deal(ans: str) -> bool:
    low = (ans or "").lower()
    return any(w in low for w in ("metamask", "meta mask", "okx", "binance")) and any(
        w in low for w in ("pay", "we'll", "we will", "плат", "оплат", "заплат"))

def project_x_reply(burst: str, ans: str, lang: str) -> str:
    low = (burst or "").lower()
    asks = any(w in low for w in (
        "official x", "x account", "twitter", "推特", "官方", "официальный x", "официальный х"))
    if not asks:
        return ans
    bad = any(w in (ans or "").lower() for w in ("don't have", "do not have", "no official", "нет официал", "没有官方"))
    if "upnetworkhq" in (ans or "").lower() and "http" in (ans or "").lower() and not bad:
        return ans
    if lang == "zh":
        return "有的。https://x.com/upnetworkhq"
    if lang == "ru":
        return "Да. https://x.com/upnetworkhq"
    return "Here it is. https://x.com/upnetworkhq"

def lang_rule(code: str) -> str:
    if code == "ru":
        return "ЯЗЫК ОТВЕТА: только русский. Ни одного английского предложения, даже если раньше в чате был английский."
    if code == "en":
        return "REPLY LANGUAGE: English only. Do not write any Russian, even if earlier messages in this chat were Russian."
    if code == "zh":
        return "回复语言：只用中文。不要写俄文或英文句子。"
    return "Язык ответа = язык последней реплики человека."

def latest_burst(hist) -> str:
    lines = []
    for msg in reversed(hist):
        if msg.get("role") != "user":
            break
        lines.append(msg.get("content") or "")
    lines.reverse()
    return "\n".join(x for x in lines if x).strip()

async def sleep_alive(peer, gen, seconds) -> bool:
    left = seconds
    while left > 0:
        if gen is not None and PEER_GEN.get(peer) != gen:
            return False
        step = min(0.7, left)
        await asyncio.sleep(step)
        left -= step
    return gen is None or PEER_GEN.get(peer) == gen

_URL = re.compile(r"https?://[^\s]+", re.I)
EDEN_URL = "https://edenwallet.pro"

def human_text(text: str) -> str:
    raw = text or ""
    urls = _URL.findall(raw)
    protected = raw
    for i, url in enumerate(urls):
        protected = protected.replace(url, f"__URL{i}__", 1)
    out = []
    for line in protected.splitlines():
        s = line.strip()
        if s.startswith("- "):
            s = s[2:]
        s = s.replace("—", ",").replace("–", ",").replace(":", ".")
        s = s.replace(" - ", ", ").replace("-", " ")
        out.append(s)
    text = "\n".join(x for x in out if x).strip()
    for i, url in enumerate(urls):
        text = text.replace(f"__URL{i}__", url)
    if re.search(r"eden", text, re.I) and "edenwallet.pro" not in text.lower():
        text = text.rstrip() + "\n" + EDEN_URL
    return text

def ready_for_group(hist, dossier, burst) -> bool:
    if (dossier or {}).get("group_link"):
        return False
    low = (burst or "").lower()
    if "?" in low or "？" in low or any(w in low for w in ("потерял", "скам", "угнан", "сколько", "почему")):
        return False
    said = " ".join((m.get("text") or "") for m in hist if m.get("role") == "assistant").lower()
    heard = " ".join((m.get("text") or "") for m in hist if m.get("role") == "user").lower()
    told = ("1200" in said or "1,200" in said) and ("телефон" in said or "phone" in said or "up network" in said)
    agreed = any(w in heard for w in ("договорил", "соглас", "давай работать", "берём", "берем"))
    return told and agreed

async def open_work_group(lead_ent, handle, note=""):
    jeremy = await client.get_entity("jeremy_rivera1")
    created = await client(CreateChannelRequest(title="Upnetwork", about="Up Network", megagroup=True))
    channel = created.chats[0]
    for people in ([jeremy, lead_ent], [jeremy]):
        try:
            await client(InviteToChannelRequest(channel, people))
            break
        except Exception as e:
            log.warning("не добавил в группу: %s", e.__class__.__name__)
    intro = (
        "Привет. Это группа Up Network. "
        "@jeremy_rivera1 ведёт коммуникации, контракт и оплату. "
        f"@{handle}, дальше по работе пишем здесь. {note}"
    ).strip()
    await client.send_message(channel, intro)
    inv = await client(ExportChatInviteRequest(channel))
    return inv.link

def reaction_for(text: str):
    t = (text or "").lower().strip()
    if any(w in t for w in ("не пиши", "стоп", "unsubscribe", "not interested", "нет спасибо")):
        return None
    if any(w in t for w in ("по рукам", "договорил", "сотрудн", "let's work", "lets work", "deal", "合作", "一起做")):
        return "🤝"
    bare = "".join(ch for ch in t if ch not in " .!！。~")
    if bare in {"ок", "ok", "ага", "да", "yes", "收到", "好", "好的", "thanks", "thank you", "спасибо", "sounds good", "got it", "понял"}:
        return "👍"
    return None

async def put_reaction(peer, msg_id, emoji):
    if not emoji:
        return
    try:
        from telethon.tl.functions.messages import SendReactionRequest
        from telethon.tl.types import ReactionEmoji
        await client(SendReactionRequest(
            peer=peer, msg_id=msg_id, reaction=[ReactionEmoji(emoticon=emoji)]))
    except Exception:
        log.info("реакция не ушла: %s", peer)

def two_bubbles(text: str):
    text = (text or "").strip()
    if len(text) < 160:
        return [text]
    if "\n\n" in text:
        a, b = text.split("\n\n", 1)
        if len(a.strip()) > 15 and len(b.strip()) > 15:
            return [a.strip(), b.strip()]
    cut = text.rfind(". ", 0, len(text) // 2 + 50)
    if cut < 40:
        return [text]
    return [text[:cut + 1].strip(), text[cut + 1:].strip()]

async def is_muted(peer) -> bool:
    try:
        doss = await db.get_dossier(int(peer))
    except (TypeError, ValueError):
        return False
    return bool((doss or {}).get("muted"))

async def humanize_send(peer, text, gen=None, reply_to=None, fast=False, photo=None):
    if await is_muted(peer):
        log.info("muted, не пишу %s", peer)
        return False
    def stale():
        return gen is not None and PEER_GEN.get(peer) != gen
    text = human_text(text)
    parts = two_bubbles(text) if fast else [text.strip()]
    for i, ch in enumerate(parts):
        if fast:
            delay = max(4, min(len(ch) / 12, 9)) / 0.7
        else:
            delay = max(16, min(len(ch) / TYPE_CPS, 95)) * random.uniform(0.92, 1.15)
            if i == 0:
                delay += random.uniform(6, 14)
        async with client.action(peer, "typing"):
            if not await sleep_alive(peer, gen, delay):
                log.info("typing cancelled for %s", peer)
                return False
        if stale() or await is_muted(peer):
            return False
        try:
            await client.send_message(peer, ch, reply_to=reply_to if i == 0 else None)
        except FloodWaitError as e:
            health.cooldown(min(e.seconds, config.FLOOD_CD_MIN * 60))
            await asyncio.sleep(e.seconds + 2)
            if stale() or await is_muted(peer):
                return False
            await client.send_message(peer, ch, reply_to=reply_to if i == 0 else None)
        if i + 1 < len(parts):
            if not await sleep_alive(peer, gen, random.uniform(2, 5)):
                return False
    if photo and os.path.exists(photo):
        await asyncio.sleep(2)
        try:
            await client.send_file(peer, photo)
        except Exception:
            log.info("фото к письму не ушло")
    return True

# ---------------- КАДЕНСЕР ----------------
def _ref(handle: str):
    h = str(handle).strip().lstrip("@")
    return int(h) if h.isdigit() else h

def opener_photo(dossier) -> str:
    lang = str((dossier or {}).get("language") or "")
    name = "first_zh.jpg" if lang.startswith("zh") else "first_en.jpg"
    path = os.path.join("assets", name)
    return path if os.path.exists(path) else "assets/first.jpg"

async def outreach_loop():
    health.beat("outreach")
    first = True
    while True:
        health.beat("outreach")
        if first:
            await asyncio.sleep(max(5, config.FIRST_DELAY))
            first = False
        else:
            pending = await db.q(
                "SELECT COUNT(*) FROM leads WHERE status='queued' AND dossier LIKE '%\"batch\": \"b5\"%'",
                fetch="one")
            gap = 5 if pending and pending[0] else config.NEW_EVERY_MIN
            wait = gap * 60
            await asyncio.sleep(max(30, wait))
        if PAUSED or health.in_cooldown() or not work_hours_ok() or os.path.exists("PAUSE_NEW"):
            continue
        day = dt.date.today().isoformat()
        if await db.today_count(day) >= config.DAILY_CAP:
            log.info("дневной лимит, новых писем нет")
            continue
        skipped = set()
        sent_now = False
        floods = 0
        for _try in range(6):
            lead = await db.next_queued(skipped)
            if not lead:
                break
            peer = lead["peer_id"]
            try:
                ent = await client.get_entity(_ref(lead["handle"]))
                peer = await db.rebind_peer(peer, ent.id)
                dossier = await db.get_dossier(peer)
                if lead.get("x_handle") and "work_link" not in dossier:
                    await enrich.enrich_if_stale(db, peer, {**lead, "enriched_at": None, "dossier": dossier})
                    dossier = await db.get_dossier(peer)
                past = await db.recent_openers(15)
                op = await llm.opener(dossier, past, FEWSHOT_CACHE)
                oid = await db.remember_opener(op)
                photo = None if (dossier or {}).get("no_photo") else opener_photo(dossier)
                await humanize_send(ent, op, photo=photo)
                await db.opener_mark_sent(oid)
                await db.set_opener(peer, oid)
                await db.log(peer, "assistant", op)
                await db.mark_first_touch(peer)
                await db.set_stage(peer, "first_touch")
                await db.bump_daily(day)
                await db.kpi_bump("newc")
                log.info("sent opener -> %s", lead["handle"])
                sent_now = True
                break
            except FloodWaitError as e:
                health.cooldown(min(e.seconds, config.FLOOD_CD_MIN * 60))
                await health.record("outreach:FloodWait")
                log.warning("flood wait %ss", e.seconds)
                await asyncio.sleep(e.seconds + 2)
                break
            except PeerFloodError:
                floods += 1
                await health.record("outreach:PeerFlood")
                skipped.add(int(peer))
                log.warning("этому пока нельзя, оставляю в очереди и беру следующего: %s", lead["handle"])
                continue
            except ForbiddenError as e:
                await db.set_status(peer, "skipped")
                await health.record("outreach:Forbidden")
                log.warning("этому человеку писать нельзя, пропускаю: %s", lead["handle"])
                continue
            except UserPrivacyRestrictedError:
                await db.set_status(peer, "unreachable")
                await health.record("outreach:Privacy")
                log.warning("у человека закрыты сообщения: %s", lead["handle"])
                continue
            except (UsernameInvalidError, UsernameNotOccupiedError, PeerIdInvalidError, ValueError) as e:
                log.warning("dead contact %s: %s", lead["handle"], e.__class__.__name__)
                await health.record(f"outreach:{e.__class__.__name__}")
                await db.set_status(peer, "dead")
                continue
            except Exception as e:
                log.exception("skip %s", lead["handle"])
                await health.record(f"outreach:{e.__class__.__name__}")
                break
        if not sent_now and not skipped:
            log.info("очередь пуста, новых писем нет")

_ACK = {
    "收到", "收到了", "好", "好的", "行", "ok", "okay", "okk", "alright", "all right",
    "got it", "thanks", "thank you", "thx", "谢谢", "嗯", "嗯嗯", "知道了", "明白",
    "noted", "kk", "k", "yep", "yup", "sure", "cool", "fine",
}

def _bare(text: str) -> str:
    drop = " .!！。~～😘❤️🙏"
    return "".join(ch for ch in (text or "").lower().strip() if ch not in drop)

def no_reply_needed(burst: str, hist: list) -> bool:
    parts = [p.strip() for p in (burst or "").splitlines() if p.strip()]
    if not parts or len(parts) > 2:
        return False
    if not all(_bare(p) in _ACK for p in parts):
        return False
    last = ""
    for msg in reversed(hist or []):
        if msg.get("role") == "assistant":
            last = msg.get("text") or ""
            break
    low = last.lower()
    if "?" in low or "？" in low:
        return False
    return True


@client.on(events.NewMessage(incoming=True, func=lambda e: e.is_private))
async def on_in(event):
    peer = event.chat_id
    if peer == ME_ID or peer in BUSY:
        return
    lead = await db.get_lead(peer)
    text = (event.raw_text or "").strip()
    if not text or not lead:
        return
    if (lead.get("dossier") or {}).get("muted") or lead.get("status") in ("refused", "dead"):
        if (lead.get("dossier") or {}).get("muted"):
            await db.log(peer, "user", text)
        return
    if LAST_EVENT.get(peer) == event.id:
        return
    LAST_EVENT[peer] = event.id
    BUSY.add(peer)
    await db.log(peer, "user", text)
    low = text.lower()
    gen = PEER_GEN.get(peer, 0) + 1
    PEER_GEN[peer] = gen

    if any(w in low for w in playbook.REFUSE_WORDS):
        await db.set_status(peer, "refused")
        await humanize_send(peer, "Принял, больше не побеспокою." if detect_lang(text) != "en" else "Understood, I won't message you again.", gen, reply_to=event.id, fast=True)
        BUSY.discard(peer)
        return

    if lead: asyncio.create_task(enrich.enrich_if_stale(db, peer, lead))

    read_for = min(16, max(4, len(text) / 18))
    if random.random() < 0.25:
        read_for += random.uniform(12, 30)
    if not await sleep_alive(peer, gen, read_for):
        BUSY.discard(peer)
        return
    try:
        await client.send_read_acknowledge(peer, event.message)
    except Exception:
        log.info("не отметил прочитанным: %s", peer)
    await put_reaction(peer, event.id, reaction_for(text))
    dossier = await db.get_dossier(peer)
    hist    = await db.history(peer)
    burst   = latest_burst(hist) or text
    while hist and hist[-1]["role"] == "user":
        hist.pop()
    dossier = await db.get_dossier(peer)
    if ready_for_group(hist, dossier, burst):
        try:
            link = await open_work_group(await event.get_chat(), lead.get("handle") or "friend")
        except Exception:
            log.exception("группа не создалась: %s", peer)
            link = ""
        if link:
            dossier["group_link"] = link
            await db.save_dossier(peer, dossier)
            text_out = (
                "По работе дальше так. Сейчас создам группу с нашим менеджером "
                "по коммуникациям, контрактам и оплате. Дальше общаемся там. " + link
            )
            if await humanize_send(peer, text_out, gen, fast=True):
                await db.log(peer, "assistant", text_out)
            BUSY.discard(peer)
            return

    replies = (lead or {}).get("replies", 0) + 1
    days    = await db.talk_days(peer)
    stage   = playbook.advance(replies, days, burst)
    tactic  = playbook.TACTIC[stage]
    saved   = await db.get_role(peer)
    role    = roles.resolve(stage, saved)
    roleobj = roles.ROLES[role]
    lessons = await db.active_lessons(stage, k=config.LESSONS_TOP)
    rule    = lang_rule(chat_lang(hist, burst))
    if no_reply_needed(burst, hist):
        log.info("молчу, отвечать не на что: %s", peer)
        BUSY.discard(peer)
        return

    need = await health.guarded("ask-owner", llm.ask_owner(burst, dossier or {}))
    if need and not await db.open_ask_for(peer):
        note_me = await client.send_message(
            "me",
            f"Нужен ответ для @{lead.get('handle') or peer}.\n"
            f"Он написал: {burst[:300]}\n\n{need}\n\n"
            "Ответь на это сообщение. Я отправлю ему только то, что ты напишешь.")
        await db.add_ask(peer, lead.get("handle") or "", need, burst, note_me.id)
        hold = "我确认一下，马上回你。" if detect_lang(burst) != "en" else "Let me confirm that and come straight back."
        if detect_lang(burst) == "ru":
            hold = "Уточню и сразу вернусь."
        if await humanize_send(peer, hold, gen, fast=True):
            await db.log(peer, "assistant", hold)
        BUSY.discard(peer)
        return

    fact = await health.guarded("public-fact", llm.public_fact(burst))
    if fact:
        rule = rule + "\nПубличный факт, можно использовать один, без совета покупать:\n" + fact
    note = await health.guarded("chat-note", llm.chat_note(hist, burst))
    if note:
        doss = await db.get_dossier(peer)
        doss["chat_note"] = note[:500]
        await db.save_dossier(peer, doss)
        dossier = doss
        rule = rule + "\nЗаметка по этому чату, не цитируй её:\n" + note
    slots   = call_slots()
    ans = await health.guarded("llm-reply",
        llm.dialogue(roleobj, dossier, stage, tactic, hist, rule + "\n\n" + burst, lessons, rule, slots))
    want = chat_lang(hist, burst)
    if ans and want and detect_lang(ans) != want:
        ans = await health.guarded("llm-reply-lang",
            llm.dialogue(roleobj, dossier, stage, tactic, hist,
                         rule + "\nПредыдущий черновик был не на том языке. Напиши заново на языке правила.\n\n" + burst,
                         lessons, rule, slots))
    if not ans or PEER_GEN.get(peer) != gen:
        BUSY.discard(peer)
        return
    cleaned = await health.guarded("llm-clean", llm.clean_reply(ans, burst, note or "", rule))
    if cleaned and PEER_GEN.get(peer) == gen:
        ans = cleaned
    aligned = await health.guarded("llm-align", llm.align(hist, burst, ans, rule))
    if aligned and PEER_GEN.get(peer) == gen:
        ans = aligned
    checked = control.review(burst, ans)
    if checked["action"] == "rewrite":
        fixed = await health.guarded("llm-repair", llm.repair(ans, burst, checked["errors"], rule))
        if fixed:
            ans = fixed
            checked = control.review(burst, ans)
    if control.echoes_him(burst, ans):
        log.info("черновик скопировал его, не отправляю: %s", peer)
        BUSY.discard(peer)
        return
    if breaks_deal(ans):
        ans = "Нет. Оплата только на Eden, потом сразу выводишь себе.\nhttps://edenwallet.pro" if "русск" in rule.lower() or chat_lang(hist, burst) == "ru" else "No. We pay only to Eden. After that you withdraw to your own wallet.\nhttps://edenwallet.pro"
    ans = project_x_reply(burst, ans, chat_lang(hist, burst))
    if not ans or ans.strip().upper() in ("SILENT", "SILENCE", "NONE") or checked["action"] == "silent":
        log.info("молчу после контроля: %s %s", peer, checked["errors"])
        BUSY.discard(peer)
        return
    reply_to = event.id if ("\n" in burst and burst.strip() != text.strip()) or random.random() < 0.3 else None
    if not await humanize_send(peer, ans, gen, reply_to=reply_to, fast=True):
        BUSY.discard(peer)
        return
    await db.log(peer, "assistant", ans)
    await db.touch(peer); await db.set_stage(peer, stage)
    await db.kpi_bump("replies")
    if lead.get("opener_id") and (lead.get("replies") or 0) == 0:
        await db.opener_hit(lead["opener_id"])

    # обещания запоминаем в досье
    if any(w in ans.lower() for w in playbook.PROMISE_WORDS):
        await db.add_promise(peer, ans[-150:])

    if any(w in burst.lower() for w in playbook.HOT_TRIGGERS):
        await db.set_status(peer, "hot"); await db.kpi_bump("hot")
        u = await db.get_lead(peer)
        await client.send_message("me",
            f"🔥 HOT {u['handle']} ({peer})\nстадия: {stage}\n"
            f"досье: {str(u['dossier'])[:300]}")
    BUSY.discard(peer)

# ---------------- АДМИН-КОМАНДЫ ----------------
HELP = """Команды (Избранное):
/roles — список ролей
/role <имя> — всем лидам с auto (general|hype|mentor|strategist|closer)
/role <имя> @юзер — одному
/mission <цель словами> — создать миссию (ИИ разложит на шаги)
/missions — прогресс миссий
/task <id миссии> <№ шага> — отметить шаг сделанным
/close <id миссии> — закрыть миссию
/teach <правило> — мгновенно научить бота правилом навсегда
/lessons — текущие активные уроки ИИ
/learn now — ночную аналитику прямо сейчас
/mailcold <текст> — нет, рассылка только автоматическая
/stats — сводка
/doctor — диагностика системы
/pause /go — стоп/пуск рассылки
/add <tg> [x-хендл] — в очередь"""

@client.on(events.NewMessage(chats="me"))
async def on_admin(event):
    cmd = event.raw_text.strip()
    if cmd and not cmd.startswith("/"):
        ask = None
        if event.reply_to_msg_id:
            ask = await db.ask_by_msg(event.reply_to_msg_id)
        if not ask:
            ask = await db.latest_open_ask()
        if ask:
            ask_id, peer, handle, question = ask
            lead = await db.get_lead(peer)
            rule = lang_rule(str((lead or {}).get("dossier", {}).get("language") or "zh"))
            ans = await health.guarded("relay", llm.relay_answer(question, cmd, rule))
            if ans and await humanize_send(peer, ans, fast=True):
                await db.log(peer, "assistant", ans)
                await db.close_ask(ask_id, cmd)
                await event.reply(f"отправил @{handle}")
            else:
                await event.reply("не смог отправить")
            return
    try:
        if cmd.startswith("/help"): await event.reply(HELP)

        elif cmd.startswith("/roles"):
            await event.reply("\n".join(f"{k}: {v['desc']}" for k,v in roles.ROLES.items()))

        elif cmd.startswith("/role "):
            _, nm, *maybe_peer = cmd.split(maxsplit=2)
            if maybe_peer and maybe_peer[0].startswith("@"):
                h = maybe_peer[0].lstrip("@")
                r = await db.q("SELECT peer_id FROM leads WHERE handle=?", (h,), "one")
                if r: await db.set_role(r[0], nm); await event.reply(f"{h}: {nm}")
                else: await event.reply("нет такого в базе")
            else:
                await db.q("UPDATE leads SET role=? WHERE role='auto'", (nm,))
                await event.reply(f"всем auto: {nm}")

        elif cmd.startswith("/mission "):
            mid, m = await missions.create_from_text(cmd[len("/mission "):])
            await event.reply(f"Миссия #{mid} создана:\n" +
                "\n".join(("▫️ "+t["d"]) for t in m["tasks"]))

        elif cmd.startswith("/missions"):
            await event.reply(await missions.render_all())

        elif cmd.startswith("/task "):
            _, mid_s, idx_s = cmd.split(); await missions.toggle_task(int(mid_s), int(idx_s))
            await event.reply("отмечено ✅")

        elif cmd.startswith("/close "):
            await db.mission_close(int(cmd.split()[1])); await event.reply("закрыто")

        elif cmd.startswith("/teach "):
            await learn.teach_rule(cmd[len("/teach "):])
            await event.reply("урок сохранён, применяю сразу")

        elif cmd.startswith("/lessons"):
            ls = await db.q("SELECT score,applies_to,insight FROM lessons WHERE active=1 "
                            "ORDER BY score DESC LIMIT 10", fetch="all")
            await event.reply("\n".join(f"{r[0]}[{r[1]}] {r[2]}" for r in ls) or "пусто")

        elif cmd.startswith("/learn now"):
            await event.reply(await learn.nightly(dt.datetime.now()))

        elif cmd.startswith("/stats"):
            await event.reply(await db.stats_str())

        elif cmd.startswith("/doctor"):
            await event.reply(await health.doctor_report(client))

        elif cmd.startswith("/pause"):
            PAUSED.clear(); PAUSED.append(True); await event.reply("рассылка стоп, диалоги живут")
        elif cmd.startswith("/go"):
            PAUSED.clear(); await event.reply("рассылка resumed")

        elif cmd.startswith("/add "):
            parts = cmd.split(maxsplit=2)
            tg = parts[1]; xh = parts[2] if len(parts)>2 else ""
            pid = await db.ensure_queued(tg, xh.lstrip("@"))
            await event.reply(f"+ {pid}")

        elif cmd.startswith("/take "):
            raw = cmd.split()[1].lstrip("@")
            row = await db.q("SELECT peer_id FROM leads WHERE handle=?", (raw.lower(),), "one")
            peer_id = row[0] if row else int(raw)
            doss = await db.get_dossier(peer_id)
            doss["muted"] = True
            await db.save_dossier(peer_id, doss)
            BUSY.add(peer_id)
            await event.reply("бот молчит там")
        elif cmd.startswith("/drop "):
            raw = cmd.split()[1].lstrip("@")
            row = await db.q("SELECT peer_id FROM leads WHERE handle=?", (raw.lower(),), "one")
            peer_id = row[0] if row else int(raw)
            doss = await db.get_dossier(peer_id)
            doss.pop("muted", None)
            await db.save_dossier(peer_id, doss)
            BUSY.discard(peer_id)
            await event.reply("бот снова отвечает")
    except Exception as e:
        await health.record(f"admin:{e.__class__.__name__}")
        await event.reply(f"ошибка команды: {e}\n/help — справка")

# ---------------- ФОНОВЫЕ СЛУЖБЫ ----------------
async def refresh_fewshot():
    global FEWSHOT_CACHE
    while True:
        try: FEWSHOT_CACHE = await db.best_openers(min_sent=2, k=config.OPENER_FEWSHOT)
        except Exception: pass
        await asyncio.sleep(6*3600)

async def scheduler():
    """Ночное обучение в LEARN_HOUR и утренний дайджест в DIGEST_HOUR."""
    done_learn = done_digest = ""
    while True:
        now = dt.datetime.now()
        key = now.strftime("%Y-%m-%d")
        if now.hour == config.LEARN_HOUR and done_learn != key:
            done_learn = key
            msg = await health.guarded("learn-night", learn.nightly(now))
            if msg: await client.send_message("me", msg)
        if now.hour == config.DIGEST_HOUR and done_digest != key:
            done_digest = key
            rep = ("☀️ ДАЙДЖЕСТ\n"+await missions.render_all()+"\n\n"+
                   await db.stats_str())
            await client.send_message("me", rep)
        await asyncio.sleep(1800)

# ---------------- СТАРТ ----------------
async def load_queue_file():
    try:
        for line in open(config.QUEUE_FILE, encoding="utf-8"):
            line=line.strip()
            if not line or line.startswith("#"): continue
            parts=line.replace(","," ").split()
            await db.ensure_queued(parts[0], parts[1] if len(parts)>1 else "")
    except FileNotFoundError:
        print("[!] queue.txt нет — очередь пустая")

async def catch_unanswered():
    await asyncio.sleep(4)
    rows = await db.q(
        "SELECT peer_id FROM leads WHERE first_touch IS NOT NULL AND status NOT IN ('dead','refused','skipped')",
        (), "all")
    for (peer,) in rows or []:
        try:
            msgs = await client.get_messages(int(peer), limit=1)
        except Exception:
            continue
        msg = msgs[0] if msgs else None
        text = (msg.text or "").strip() if msg else ""
        if not msg or msg.out or not text:
            continue
        age = (dt.datetime.now(dt.timezone.utc) - msg.date).total_seconds()
        if age > 6 * 3600:
            continue
        last = await db.q(
            "SELECT role, text FROM msgs WHERE peer_id=? ORDER BY id DESC LIMIT 1",
            (int(peer),), "one")
        if last and last[0] == "assistant":
            continue
        if not last or (last[1] or "").strip() != text:
            await db.log(int(peer), "user", text)
        lead = await db.get_lead(int(peer))
        if not lead:
            continue
        dossier = await db.get_dossier(int(peer))
        if (dossier or {}).get("muted") or int(peer) in BUSY:
            continue
        hist = await db.history(int(peer))
        while hist and hist[-1]["role"] == "user":
            hist.pop()
        rule = lang_rule(chat_lang(hist, text))
        role = roles.ROLES["general"]
        ans = await health.guarded("llm-reply",
            llm.dialogue(role, dossier, "rapport", "", hist, rule + "\n\n" + text, [], rule, ""))
        if breaks_deal(ans):
            ans = "Нет. Оплата только на Eden, потом сразу выводишь себе.\nhttps://edenwallet.pro" if chat_lang(hist, text) == "ru" else "No. We pay only to Eden. After that you withdraw to your own wallet.\nhttps://edenwallet.pro"
        if not ans or ans.strip().upper() in ("SILENT", "SILENCE", "NONE"):
            continue
        if await humanize_send(int(peer), ans, fast=True):
            await db.log(int(peer), "assistant", ans)
            log.info("догнал пропущенный ответ: %s", lead.get("handle"))

async def main():
    global ME_ID
    bad = config.missing_keys()
    if bad:
        raise SystemExit("Заполни .env. Пусто или пример: " + ", ".join(bad))
    await db.init()
    await load_queue_file()
    await client.start(phone=config.PHONE)
    ME_ID = (await client.get_me()).id
    log.info("AGENT ONLINE. Пиши /help в Избранное.")
    asyncio.create_task(outreach_loop())
    asyncio.create_task(catch_unanswered())
    asyncio.create_task(refresh_fewshot())
    asyncio.create_task(scheduler())
    asyncio.create_task(health.supervisor(lambda: None))
    await client.run_until_disconnected()

if __name__=="__main__":
    asyncio.run(main())