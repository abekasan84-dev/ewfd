# МИССИИ: цели словами -> разборка DeepSeek -> учёт прогресса из KPI.

import json, asyncio
import db, llm, health, config

METRIC_LABEL = {"NEW":"новые контакты","REPLY":"ответов получено","HOT":"горячих"}

async def create_from_text(goal_text:str):
    m = await health.guarded("mission-decomp", llm.decompose(goal_text))
    if not m or not isinstance(m, dict) or not m.get("title"):
        raise ValueError("LLM не вернул разборку, переформулируй цель")
    mid = await db.mission_add(m["title"], m.get("metric","NEW"),
                               float(m.get("target",10)),
                               m.get("deadline",""),
                               json.dumps(m.get("tasks",[]), ensure_ascii=False))
    return mid, m

async def progress_row(row) -> str:
    _id,title,metric,target,deadline,tasks,status,created = row
    done_val = await db.kpi_sum(metric.lower())          # накоплено всего
    tasks_arr = json.loads(tasks or "[]")
    td = sum(1 for t in tasks_arr if t.get("done"))
    bar = "█"*max(0,min(10,int(done_val/max(target,1)*10)))
    bar += "░"*(10-len(bar))
    tail = f" | дедлайн {deadline}" if deadline else ""
    task_lines = "\n".join(("✅" if t["done"] else "▫️")+t["d"]
                           for t in tasks_arr)
    return (f"[#{_id}] {title}\n"
            f"Метрика: {METRIC_LABEL.get(metric,metric)} "
            f"{done_val:.0f}/{target:.0f} {bar}\n{tail}\n{task_lines}")

async def render_all():
    rows = await db.missions_active()
    if not rows: return "Активных миссий нет. Создать: /mission <цель словами>"
    return "\n\n".join(await progress_row(r) for r in rows)

async def toggle_task(mid, idx):
    await db.mission_set_task(mid, idx-1, True)