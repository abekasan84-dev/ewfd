ORDER  = ["first_touch","rapport","peer_talk","value_drop","ask_meeting","need_call"]

TACTIC = {
 "first_touch": "живой ответ на его слова и одна деталь. Про деньги только если он спросил. Звонок, слоты и слова call, созвон, zoom не употребляй.",
 "rapport": "ответь на то, что он написал, и объясни один недостающий кусок. Звонок пока не предлагай.",
 "peer_talk": "продолжай объяснять по его вопросу. К звонку не перескакивай.",
 "value_drop": "он уже в разговоре. Коротко доскажи условие, если он его ещё не слышал. Слоты не ставь.",
 "ask_meeting": "он сам хочет продолжить. Тогда, и только тогда, предложи ровно два слота: день и час. Без давления.",
 "need_call": "он выбрал время. Одной фразой зафиксируй день, число и час. Если пояс не назван, уточни его в той же фразе.",
}

HOT_TRIGGERS = ["созвон", "давай созвон", "можно позвонить", "hop on a call",
                "let's hop", "lets hop", "schedule a call", "jump on a call"]

REFUSE_WORDS = ["не пиши","отписаться","спам","стоп"]
PROMISE_WORDS = ["завтра","послезавтра","вечером","скину","напишу",
                 "на неделе","через час"]

def advance(replies:int, days:int, text:str) -> str:
    t = text.lower()
    if any(w in t for w in ("завтра","послезавтра","сегодня","tomorrow","today","утром","вечером")) and any(ch.isdigit() for ch in t):
        return "need_call"
    if any(w in t for w in HOT_TRIGGERS):
        return "ask_meeting"
    if replies >= 4:
        return "ask_meeting"
    if replies >= 2:
        return "value_drop"
    if replies >= 1:
        return "rapport"
    return "first_touch"