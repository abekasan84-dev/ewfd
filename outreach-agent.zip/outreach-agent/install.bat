@echo off
cd /d "%~dp0"
python --version >nul 2>&1
if errorlevel 1 (
  echo Установи Python 3.10+ с python.org и отметь "Add python to PATH"
  pause
  exit /b 1
)
python -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo Откроется .env — вставь ключи Telegram и DeepSeek, сохрани файл.
echo Потом запусти start.bat
notepad .env
pause
