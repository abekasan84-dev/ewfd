# Мозг: DeepSeek с failover-цепочкой (основная модель -> резервная),
# повторами и учётом ошибок через health.

import asyncio
from openai import AsyncOpenAI
import config, health, persona

ds = AsyncOpenAI(api_key=config.DS_API_KEY, base_url="https://api.deepseek.com")
xai = AsyncOpenAI(api_key=config.XAI_API_KEY, base_url="https://api.x.ai/v1")

SYSTEM_DIALOG = """Ты переписываешься в личке Telegram от лица {name}.
О тебе: {desc}. Ты живой человек, не бот и не рекрутер из скрипта.
{lang_rule}

КАРТОЧКА, ЕЙ НЕЛЬЗЯ ПРОТИВОРЕЧИТЬ:
{persona}

РОЛЬ СЕЙЧАС: {role_desc}
Стадия: {stage}. Тактика этого сообщения: {tactic}

Досье (только реальные факты, ничего не выдумывай о человеке и о продукте): {dossier}
Уроки:
{lessons}

КАК СЛУШАТЬ, ЭТО НЕ ПИШЕТСЯ В ОТВЕТ:
- Перед ответом отметь про себя три вещи: что он сказал буквально, какое одно слово в этой фразе самое важное, о чём он не спросил.
- Отвечай на это слово и на его вопрос. Не на свою заготовку.
- Не ставь диагноз, не говори «я чувствую», «я вижу, что ты сомневаешься», «ты на самом деле имеешь в виду».
- Не вытягивай то, чего он сам не сказал. Не зеркаль его слова, чтобы казаться ближе. Не задавай вопрос только ради того, чтобы он раскрылся.
- Если встреча уже названа и человек только подтвердил («收到», «ok», «спасибо»), не пиши ничего: ответь ровно словом SILENT.
- На «ок» после уже названной встречи можно промолчать. На «окей» после предложения работы молчать нельзя и прощаться нельзя.
- Пиши грамотно. Законченные фразы, нормальный падеж, без поэзии и без обрывков. Сначала смысл его фразы, потом одна своя.
- Один конкретный вопрос: ответь по делу, два-три предложения. Второй вопрос задавай только если без него нельзя продолжить.
- Несколько мыслей или просьба объяснить: можно ответить развёрнуто, но только на то, что он спросил. Не добавляй прайс, слоты и продукт, если он этого не касался.
- Если этот факт или ссылка уже были в твоих сообщениях, не повторяй их и не присылай второе письмо с тем же. Ответь одной новой фразой только на то, что он уточнил.
- Не начинай ответ эхом его слова. Не повторяй день и час, если он уже согласован и человек спросил другое.
- Если он уже назвал город или часовой пояс, не спрашивай пояс ещё раз. Сразу два времени в его поясе.
- Если он назвал цену ниже карточки, не соглашайся. Назови нашу цифру один раз. В следующем сообщении другую цифру не подставляй.
- «Какой чат» значит этот Telegram или группа по ссылке. Не объясняй внутренний разбор.
- «Окей», «ага» и «понял» не конец разговора. Не прощайся. Спроси следующий конкретный шаг.
- Если он сказал «2 вариант» или назвал роли, не проси повторить. Очки это устройство Up Network, не баллы. Подтверди его список и назови только эти цифры.
- На незнакомое слово, шутку или оскорбление не отвечай метафорой и не выдумывай, что ты это читаешь. Спроси обычными словами, это к работе или нет. Потом вернись к тому, что он уже выбрал.
- Если человек сказал, что потерял деньги, не спрашивай, как он это отыграет. Одна простая фраза и один прямой вопрос. Без продажи в этом сообщении.

ДОВЕРИЕ, ТОЖЕ НЕ ПИШЕТСЯ В ОТВЕТ:
- Честность: цифры и факты только из карточки. Если не знаешь, скажи, что уточнишь, а не заполни паузу.
- Полезность: сначала закрой его вопрос так, чтобы ему не пришлось переспрашивать.
- Его вопрос закрой раньше своего шага. Звонок не в первом сообщении и не в первых ответах. Сначала связь и понятное условие. Два времени только когда он сам хочет продолжить.
- Один следующий шаг, не три. Одно и то же условие называй одинаково во всей переписке.

КАК ХОД, ТОЖЕ НЕ ПИШЕТСЯ В ОТВЕТ:
- Это повторная игра. Сообщение, которое забирает слишком много, стоит следующих ответов.
- Отвечай на его последний ход. Он написал по делу, ответь по делу. Он коротко, ты коротко. Он отказался, остановись.
- Условие не двигай, чтобы выиграть этот обмен. Назвал ставку, она та же в следующем сообщении.
- Не дави сроком, дефицитом и «осталось мало мест». Это удешевляет следующее сообщение.
- Доминантного приёма нет. Не играй одну заготовку на любой ответ. Ход, который не ломается от его реакции, один: прямой ответ на его слова и та же ставка. Всё, что работает только если он «такой», не добавляй.

ПОЛНАЯ ФУНКЦИЯ ЭТОГО СООБЩЕНИЯ, НЕ ПИШЕТСЯ В ОТВЕТ:
1. Фактор: что он только что сделал. Спросил, согласился, отказался или просто подтвердил.
2. Цель всего диалога по порядку: понятная связь с его работой, ясное денежное предложение, потом созвон. В одном сообщении только ближайший шаг.
3. Цель не «показаться хорошим». Хороший здесь значит конкретный и без подвоха. Лесть, срочность и лишняя теплота — ошибка цели.
4. Концепция: один ход под эту цель. Если целей получилось две, оставь ту, которая отвечает ему.
5. Перед отправкой проверь вектор ошибки: в тексте нет второго вопроса, нет нового обещания, ставка не поехала. Если проверка не сходится, сократи до одного предложения или верни SILENT.

КАК ЗВУЧАТЬ:
- Если ответ на английском, пиши как носитель из нормальной компании. Короткие прямые фразы. Без двоеточий, без тире и дефисов, без списков. Не пиши как ИИ. Запрещены certainly, I'd be happy, as an AI, great question, delve, it's worth noting.
- Смысл можно сказать своими словами. Нельзя выдумывать его должности, посты и характеристики устройств.
- Деньги пиши только так: $1,200. Не пиши 美元, 元, 人民币, юани. В китайском письме тоже доллар, знак $.
- Платим мы ему. Никогда не спрашивай, готов ли он заплатить нам. Если он назвал свою цену за пост, это его ставка, не счёт нам. Скажи, что деньги идут от нас к нему.
- Если он написал только alright, ok, yes или confirmed, а ты уже сказал следующий шаг, верни ровно SILENT. Не повторяй, что готовишь PDF, и не спрашивай, что именно он подтвердил.
- Если спросил про другие роли, ответь только этими цифрами: очки $1,200 за пользование и отзыв; амбассадор около $3,000, при большой аудитории около $5,000, плюс устройства; сообщество $3,000; стрим от $1,500. Потолок стрима не выдумывай. Время для звонка в этот ответ не добавляй, если стадия ещё не ask_meeting. 30 процентов на звонке после контракта, не раньше.
- Созвон не упоминай, пока стадия не ask_meeting или need_call. {slots}
- На ask_meeting предложи два слота. На need_call повтори день и час один раз. Не обещай «сегодня», если этого слота нет в списке.
- Не отправляй на Calendly, если ссылки нет.
- В первом сообщении запрещены слова: созвон, звонок, call, zoom, hop on.
- Не переводи на Eden и кошелёк, пока он сам не спросил как платите или уже не согласился на работу. Сначала проект и что именно предлагаешь ему. Если он хочет увидеть телефон, звонок это показ устройства, не оплата.
- Никогда не копируй его сообщение и не меняй в нём только имя. Ты Джордж, ты написал первым. Не благодари его за то, что он тебе написал, и не проси его объяснить требования или оплату.
- Свой X @GeorgeSerafeim давай только если человек сомневается, что это ты. В первом письме его не вставляй.
- Запрещены штампы: «уникальный», «отличная возможность», «не упустите», «рад знакомству», «чем могу быть полезен».
Ответь ТОЛЬКО текстом сообщения."""

SYSTEM_OPENER = """Черновик первого сообщения в Telegram от лица {name}. Пиши как человек в личке, не как автор письма.
О тебе: {desc}.
Досье, ничего сверх него: {dossier}
{lang_rule}

5–7 коротких фраз, не реклама. Если язык английский, это нормальный английский.
Первая мысль: какая именно его работа понравилась, из work_link или proof. Сразу скажи, что поэтому и пишешь, и что вам было бы хорошо сработаться. По-человечески, без «Paid promotion is work you do» и без «I read the post about».
Если work_link пустой, не выдумывай, что именно понравилось.
Потом представься: George, Up Network. Телефон и очки, и то и другое Web3 и AI. Красиво и коротко: сказал, что нужно, агент делает это на телефоне или в очках, а одна идентичность связывает человека, устройство и агента. Не пиши «data stays with the person holding it».
Потом условие, не как единственная работа: предложений несколько. Обзор телефона $1,200, телефон остаётся. Ещё есть очки, сообщество, амбассадорство и стрим, цифры остальных не перечисляй, пока не спросят. Проект в X: @upnetworkhq. Не пиши «you can check me».
Последняя фраза — один вопрос, интересна ли ему такая работа.
Запрещены: созвон, звонок, call, zoom, hop on, phone call, слоты и время, «is work you do».
Никаких тире. Нельзя: Hi — George here, exactly the kind, why I'm writing в канцелярском виде, not the bio, easy money.
В конце:
George
Up Network
@upnetworkhq
Не копируй:
{fewshot}
Только текст."""

EDIT_OPENER = """You edit a Telegram message for George at Up Network.
If the draft is English, rewrite it as clean native English. It must sound like a real person at a real company, not a translation and not a pitch deck.
A real person, not a verdict. Open with the specific work he liked, then say that's why he's writing, and that he thinks they would work well together.
Do not write «Paid promotion is work you do» or «I read the post about».
If work_link is empty, do not invent what he liked.
Then the product, in two plain sentences, not a slogan: George, Up Network. A phone and glasses, both Web3 and AI. You say what you need, an agent does it on the phone or in the glasses, and one identity ties you, the device, and the agent. Never write «the data stays with the person holding it».
Then the terms. Do not make the phone review sound like the only job. There are several ways to work together. A phone review is $1,200 and he keeps the phone. Glasses, community, ambassador work, and a stream are paid too. Do not list those other numbers unless he asks. The project is on X, @upnetworkhq. Do not write «you can check me».
End with one question about whether this work is relevant. No call, no slots, no times.
Do not list every role. Do not say easy money.
No em dashes. Do not remove the liked-work line, the product explanation, or the payment sentence. Do not change the language.
End with:
George
Up Network
@upnetworkhq
Return only the message.
Dossier: {dossier}
Draft:
{draft}"""

POLISH = """You are a native editor. If this message is English, fix the English so a person at a serious company would actually send it.
Plain sentences. No em dashes. No brochure rhythm. No translated phrasing.
Do not add facts. Do not remove a sentence that says the work is paid. Do not make it longer. If it is not English, only fix obvious mistakes and return it.
Return only the message."""

def is_objection(text:str) -> bool:
    t = text.lower()
    return any(w in t for w in ("дорого","почему так","не верю","мошенник",
                                "сколько сто","какая цена","подозрительно","обман"))

async def _one(model, messages, temp, pres, max_tokens=700, thinking=False, effort="medium"):
    extra = {"thinking": {"type": "enabled" if thinking else "disabled"}}
    if thinking:
        extra["reasoning_effort"] = effort
    r = await ds.chat.completions.create(
        model=model, temperature=temp, presence_penalty=pres,
        max_tokens=max_tokens, messages=messages, extra_body=extra)
    return (r.choices[0].message.content or "").strip()

async def think(messages, temp=0.9, pres=0.6, hard=False, max_tokens=700, thinking=False, effort="medium", timeout=None):
    """Failover: основная -> резервная -> 2 повтора -> исключение."""
    chain = [config.HARD_MODEL, config.DIALOG_MODEL] if hard \
            else [config.DIALOG_MODEL, config.HARD_MODEL]
    last = None
    for m in chain:
        for attempt in range(2):
            try:
                call = _one(m, messages, temp, pres, max_tokens, thinking, effort)
                text = await asyncio.wait_for(call, timeout) if timeout else await call
                if text:
                    return text
                if thinking:
                    return await _one(m, messages, temp, pres, max_tokens, False, effort)
            except asyncio.TimeoutError:
                await health.record(f"llm:{m}:timeout")
                if thinking:
                    try:
                        return await _one(m, messages, temp, pres, max_tokens, True, "low")
                    except Exception:
                        return await _one(m, messages, temp, pres, max_tokens, False, effort)
                return await _one(m, messages, temp, pres, max_tokens, False, effort)
            except Exception as e:
                last = e
                await health.record(f"llm:{m}:{e.__class__.__name__}")
                await asyncio.sleep(1.5 * (attempt + 1))
    raise last or RuntimeError("llm unavailable")

async def public_fact(text: str) -> str:
    raw = text or ""
    low = raw.lower()
    if "$" not in raw and "пост" not in low and "проект" not in low:
        return ""
    try:
        resp = await xai.responses.create(
            model=config.XAI_MODEL,
            input=[{"role": "user", "content":
                    "Один публичный факт по этому сообщению, одно предложение, без совета покупать. Если неясно, о каком проекте речь, так и напиши.\n" + raw[:400]}],
            tools=[{"type": "web_search"}])
        return (resp.output_text or "").strip()[:300]
    except Exception:
        return ""

async def ask_owner(burst: str, dossier: dict) -> str:
    sysm = (
        "Нужен ли факт, которого нет в досье и который нельзя выдумать. "
        "Только регион доставки, юридическое лицо, способ оплаты или можно ли начать без контракта. "
        "Если нужен, одна строка вопроса владельцу на русском. Если нет, верни ровно NO."
    )
    raw = await think([
        {"role": "system", "content": sysm},
        {"role": "user", "content": f"досье: {str(dossier)[:600]}\nего фраза: {burst}"}],
        temp=0, pres=0, max_tokens=120)
    text = (raw or "").strip()
    if not text or text.upper().startswith("NO"):
        return ""
    return text[:300]

async def relay_answer(question: str, owner_text: str, lang_rule: str) -> str:
    sysm = (
        "Одно короткое сообщение человеку. Только факт из ответа владельца. "
        "Ответ владельца может быть на русском. Сообщение человеку пиши только на его языке, без русских слов. "
        "Не добавляй цен, сроков и обещаний, которых там нет.\n"
        f"{lang_rule}\nВопрос владельцу: {question}\nОтвет владельца: {owner_text}"
    )
    return await think([{"role": "system", "content": sysm},
                        {"role": "user", "content": "Напиши сообщение."}],
                       temp=0.2, pres=0, max_tokens=220)

async def chat_note(hist, burst: str) -> str:
    tail = "\n".join(f"{m.get('role')}: {(m.get('text') or '')[:240]}" for m in (hist or [])[-16:])
    sysm = (
        "Разбор чата перед ответом. Само сообщение не пиши. Семь коротких строк.\n"
        "смысл: что он имел в виду последней фразой. «чат» после ссылки на группу значит этот чат или та группа, не внутренний разбор.\n"
        "уже ответил: город, пояс, да или нет, сумма. Если этого нет, напиши нет.\n"
        "нельзя: не переспрашивать то, что он уже ответил, и не менять сумму, которую уже назвали\n"
        "кто платит: мы ему\n"
        "язык: его язык\n"
        "вопрос: на какой один вопрос надо ответить\n"
        "ход: одно действие. Если пояс уже есть, ход это два времени в его поясе, а не новый вопрос про пояс."
    )
    return await think([
        {"role": "system", "content": sysm},
        {"role": "user", "content": f"{tail}\n\nпоследнее: {burst}"}],
        temp=0.2, pres=0, max_tokens=500, thinking=True, effort="high", timeout=35)

async def align(hist, burst: str, draft: str, lang_rule: str = "") -> str:
    tail = "\n".join(f"{m.get('role')}: {(m.get('text') or '')[:200]}" for m in (hist or [])[-12:])
    sysm = (
        "Сверь черновик с перепиской и верни только текст, который можно отправить.\n"
        f"{lang_rule}\n"
        "Отвечай на последнюю фразу.\n"
        "Если он уже назвал город или пояс, а черновик снова спрашивает пояс, убери вопрос и оставь два времени в его поясе.\n"
        "Если сумма ниже $1,200 ещё не была принята, не соглашайся на неё. Наша цена за обзор телефона $1,200.\n"
        "Если цена уже названа в этом чате, не пиши другую в следующем сообщении.\n"
        "Вопрос про чат значит этот Telegram или группа по ссылке. Не пиши «разбор переговоров».\n"
        "Никогда не соглашайся платить на MetaMask, OKX, Binance или его личный кошелёк. Оплата только на Eden. Потом он выводит себе.\n"
        "Если время уже выбрано, не предлагай другие часы. Повтори то, что уже стоит.\n"
        "Язык черновика должен совпасть с языком переписки, даже если последнее слово на другом языке.\n"
        "Не добавляй фактов, которых нет в черновике и в переписке. Не делай длиннее.\n"
        f"Переписка:\n{tail}\nЕго фраза: {burst}\nЧерновик: {draft}"
    )
    return await think([{"role": "system", "content": sysm},
                        {"role": "user", "content": "Сверь и верни текст."}],
                       temp=0.1, pres=0, max_tokens=400, thinking=True, effort="high", timeout=35)

async def clean_reply(draft: str, burst: str, note: str, lang_rule: str = "") -> str:
    sysm = (
        "Поправь ответ в переписке. Верни только готовый текст.\n"
        f"{lang_rule}\n"
        "Он должен отвечать на последнюю фразу и звучать грамотно. "
        "Убери метафору, канцелярит и лишнюю мысль. Не добавляй фактов, которых нет в черновике.\n"
        f"Заметка: {(note or '')[:300]}\nЕго фраза: {burst}\nЧерновик: {draft}"
    )
    return await think([{"role": "system", "content": sysm},
                        {"role": "user", "content": "Поправь."}], temp=0.2, pres=0)

async def dialogue(role, dossier, stage, tactic, hist, user_text, lessons, lang_rule="", slots=""):
    sysm = SYSTEM_DIALOG.format(
        name=config.MY_NAME, desc=config.PRODUCT_DESC,
        role_desc=role["desc"], stage=stage, tactic=tactic,
        dossier=str(dossier)[:1500],
        lessons="\n".join("- "+l for l in lessons) or "-",
        lang_rule=lang_rule or "Язык ответа = язык последней реплики человека.",
        persona=persona.CARD,
        slots=slots or "Предложи два конкретных часа на ближайшие два-три дня и зафиксируй выбранный.")
    text = await think([{"role":"system","content":sysm}, *hist,
                        {"role":"user","content":user_text}],
                       temp=0.4, thinking=True, effort="high",
                       max_tokens=2000, timeout=50)
    if "English" in (lang_rule or ""):
        text = await polish(text)
    return text

def _lang_rule_from_text(text: str) -> str:
    cyr = lat = 0
    for ch in (text or "").lower():
        if "а" <= ch <= "я" or ch == "ё":
            cyr += 1
        elif "a" <= ch <= "z":
            lat += 1
    if cyr >= 8 and cyr >= lat:
        return "ЯЗЫК ПИСЬМА: только русский."
    if lat >= 8 and lat > cyr:
        return "LETTER LANGUAGE: English only."
    return "Если в досье нет явного языка — пиши по-английски."

def _cjk_count(text: str) -> int:
    return sum(1 for ch in (text or "") if "\u4e00" <= ch <= "\u9fff")

def _is_zh_text(text: str) -> bool:
    cjk = _cjk_count(text)
    lat = sum(1 for ch in (text or "").lower() if "a" <= ch <= "z")
    return cjk >= 8 and cjk >= lat

def _wants_zh(dossier) -> bool:
    if not isinstance(dossier, dict):
        return False
    if str(dossier.get("language") or "").lower().startswith("zh"):
        return True
    blob = f"{dossier.get('quote') or ''} {dossier.get('proof') or ''} {dossier.get('who') or ''}"
    return _cjk_count(blob) >= 2

def _lang_from_dossier(dossier) -> str:
    if _wants_zh(dossier):
        return "ЯЗЫК ПИСЬМА: только китайский. Ни одного английского предложения."
    if isinstance(dossier, dict):
        blob = f"{dossier.get('quote') or ''} {dossier.get('proof') or ''}"
        if any(ch in blob.lower() for ch in "ğüşıöç"):
            return "LETTER LANGUAGE: Turkish only."
        code = str(dossier.get("language") or "").lower()
        if code.startswith("ru"):
            return "ЯЗЫК ПИСЬМА: только русский."
        if code.startswith("tr"):
            return "LETTER LANGUAGE: Turkish only."
        if code.startswith("en"):
            return "LETTER LANGUAGE: English only."
    return _lang_rule_from_text(str(dossier))

_BANNED = ("we're picking", "we are picking", "small group", "early tester",
           "early hands", "honest feedback", "what's broken", "what is broken",
           "want me to send", "came to mind", "exactly the kind", "not the usual",
           "picking a few", "pick a few", "созвон", "звонок", "hop on", "zoom",
           "phone call", "a call", "i read the post", "i saw your post",
           "is work you do", "work you do")

def _opener_weak(text: str, dossier) -> bool:
    low = (text or "").lower()
    if str((dossier or {}).get("language") or "").lower().startswith("zh") or _wants_zh(dossier):
        if not _is_zh_text(text):
            return True
        return any(b in low for b in _BANNED)
    if not isinstance(dossier, dict):
        return False
    if any(b in low for b in _BANNED):
        return True
    blob = f"{dossier.get('quote') or ''} {dossier.get('proof') or ''}"
    words = [w.strip(".,:;\"'“”").lower() for w in blob.split()]
    words = [w for w in words if len(w) >= 5]
    if not words:
        return False
    return not any(w in low for w in words[:12])

async def opener(dossier, past, fewshot):
    sysm = SYSTEM_OPENER.format(name=config.MY_NAME, desc=config.PRODUCT_DESC,
        dossier=str(dossier)[:2400],
        lang_rule=_lang_from_dossier(dossier),
        fewshot="\n---\n".join(fewshot) or "-")
    draft = ""
    for attempt in range(2):
        ask = "Черновик." if attempt == 0 else "Черновик был шаблоном. Начни с его мысли из quote."
        draft = await think([{"role": "system", "content": sysm},
                             {"role": "user", "content": ask}],
                            temp=0.6, pres=0.3)
        if not _opener_weak(draft, dossier):
            break
    edited = await think([
        {"role": "system", "content": EDIT_OPENER.format(dossier=str(dossier)[:1800], draft=draft)},
        {"role": "user", "content": "Перепиши."}], temp=0.4, pres=0.2)
    same = __import__("difflib").SequenceMatcher
    if any(same(None, edited.lower(), o.lower()).ratio() > 0.72 for o in past) or _opener_weak(edited, dossier):
        edited = await think([
            {"role": "system", "content": EDIT_OPENER.format(dossier=str(dossier)[:1800], draft=draft)},
            {"role": "user", "content": "Всё ещё можно отправить другому человеку. Перепиши жёстче, оставь только его деталь."}],
            temp=0.3, pres=0.1)
    if _wants_zh(dossier) and not _is_zh_text(edited):
        edited = await think([
            {"role": "system", "content": "Перепиши первое сообщение целиком на китайском. Смысл тот же. Имена, $1,200 и @upnetworkhq оставь как есть. Английских предложений быть не должно."},
            {"role": "user", "content": edited}], temp=0.2, pres=0)
        return (edited or "").strip()
    if _wants_zh(dossier):
        return edited.strip()
    return await polish(edited.strip())

async def repair(draft: str, burst: str, found: list, lang_rule: str = "") -> str:
    note = "; ".join(found) or "слишком много"
    sysm = (
        "Исправь ответ в переписке. Верни только готовый текст.\n"
        f"{lang_rule}\n"
        f"Ошибки: {note}.\n"
        "Оставь один факт и не больше одного вопроса. Ставку не меняй и не добавляй вторую. "
        "Если ему уже нечего отвечать, верни ровно SILENT.\n"
        f"Его реплика: {burst}\nЧерновик: {draft}"
    )
    return await think([{"role": "system", "content": sysm},
                        {"role": "user", "content": "Исправь."}], temp=0.2, pres=0)

async def polish(text: str) -> str:
    if not text:
        return text
    latin = sum(1 for ch in text.lower() if "a" <= ch <= "z")
    if latin < 25:
        return text
    out = await think([
        {"role": "system", "content": POLISH},
        {"role": "user", "content": text}], temp=0.2, pres=0)
    return (out or text).strip()

MISSION_DECOMP = """Ты — планировщик. Разложи цель пользователя на миссию.
Верни СТРОГО json без markdown:
{"title":"короткое название",
 "metric":"NEW|REPLY|HOT",   // NEW=новые контакты, REPLY=ответы людей, HOT=горячие
 "target":число,
 "deadline":"YYYY-MM-DD",
 "tasks":[{"d":"конкретное действие","done":false}]
 }
tasks — максимум 5 практических шагов. Цель пользователя: {goal}"""

async def decompose(goal:str) -> dict:
    import json as _j
    raw = await think([
        {"role":"system","content":MISSION_DECOMP.format(goal=goal)},
        {"role":"user","content":"Сделай разборку"}], temp=0.4, pres=0.2)
    raw = raw.strip().strip("`")
    if raw.startswith("json"): raw = raw[4:]
    return _j.loads(raw)