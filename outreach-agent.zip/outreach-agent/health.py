# Самоисцеление: лог ошибок, сердцебиения фоновых задач, сторожевой пёс.

import time, asyncio, traceback
import config, db

HEARTBEATS = {}          # имя задачи -> последний таймштамп
COOLDOWN_UNTIL = 0.0     # глобальное охлаждение при флуде

def beat(name):          HEARTBEATS[name] = time.time()
def age(name):
    return time.time() - HEARTBEATS.get(name, 0)

def cooldown(seconds):
    global COOLDOWN_UNTIL
    COOLDOWN_UNTIL = max(COOLDOWN_UNTIL, time.time() + seconds)

def in_cooldown():
    return time.time() < COOLDOWN_UNTIL

async def record(kind):
    try: await db.errlog(kind)
    except Exception: pass

async def supervisor(outreach_factory):
    """Раз в 5 минут проверяет живость рассылки и перезапускает её."""
    while True:
        await asyncio.sleep(300)
        expected = config.NEW_EVERY_MIN * 60 * 2 + 900
        if age("outreach") > expected and not in_cooldown():
            print("[supervisor] рассылка зависла — перезапуск")
            try: outreach_factory()
            except Exception as e:
                await record(f"supervisor:{e}")

async def guarded(coro_name, coro):
    """Обёртка: не даёт исключению убить цикл."""
    try:
        return await coro
    except Exception as e:
        await record(f"{coro_name}:{e.__class__.__name__}")
        print(f"[{coro_name}] {e}\n{traceback.format_exc(limit=2)}")
        return None

async def doctor_report(client) -> str:
    lines = [f"* DOCTOR {dt_now()}"]
    missing = [k for k,v in {
        "DEEPSEEK_API_KEY": config.DS_API_KEY, "XAI_API_KEY": config.XAI_API_KEY,
        "TG_API_ID": config.API_ID}.items() if not v]
    lines.append("env: OK" if not missing else f"env НЕ ЗАДАНО: {missing}")
    try:
        me = await client.get_me()
        lines.append(f"tg session: OK ({me.first_name})")
    except Exception as e:
        lines.append(f"tg session: FAIL ({e})")
    et = await db.errors_today()
    lines.append(f"errors_today: {et} {'⚠️ смотреть' if et>15 else ''}")
    lines.append(f"cooldown: {'да, до ' + _until() if in_cooldown() else 'нет'}")
    for name, t in HEARTBEATS.items():
        lines.append(f"beat {name}: {int(age(name))}s ago")
    return "\n".join(lines)

import datetime as _dt
def dt_now(): return _dt.datetime.now().strftime("%d.%m %H:%M")
def _until():
    sec = int(COOLDOWN_UNTIL - time.time())
    return f"{sec//60}мин"