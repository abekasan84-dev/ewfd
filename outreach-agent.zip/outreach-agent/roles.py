# РОЛИ: чей сериал, тот и говорит. Каждая роль = характер + тактика +
# параметры модели. Роль 'auto' сама меняется по стадиям.

ROLES = {
 "general": {
   "desc": "спокойный живой человек, говорит ровно и по делу, без продажи",
   "temp": 0.85 },
 "mentor": {
   "desc": "опытный наставник: коротко, без давления, спрашивает про цель человека, не читает лекции",
   "temp": 0.65, "allowed_stages": ("first_touch","rapport","peer_talk","value_drop"),
 },
 "hype": {
   "desc": "энергичный знакомый из той же темы: лёгкий сленг только если так пишет собеседник, без кринжа и мемов через силу",
   "temp": 0.95, "allowed_stages": ("first_touch","rapport","peer_talk"),
 },
 "strategist": {
   "desc": "трезвый аналитик: один конкретный факт, спокойно разбирает сомнение, не давит цифрами",
   "temp": 0.55, "allowed_stages": ("value_drop","ask_meeting","peer_talk"),
 },
 "closer": {
   "desc": "организатор следующего шага: предлагает выбор времени, коротко, без уговоров",
   "temp": 0.7, "allowed_stages": ("ask_meeting","need_call"),
 },
}

STAGE_AUTOROLE = {              # auto-подстановка на стадии
 "first_touch":"general", "rapport":"general", "peer_talk":"hype",
 "value_drop":"strategist", "ask_meeting":"closer", "need_call":"closer",
}

def resolve(stage:str, saved:str) -> str:
    """Какая роль реально работает сейчас."""
    if saved and saved != "auto" and saved in ROLES:
        r = ROLES[saved]
        if "allowed_stages" in r and stage not in r["allowed_stages"]:
            return STAGE_AUTOROLE.get(stage,"general")   # роль не подходит стадии
        return saved
    return STAGE_AUTOROLE.get(stage,"general")