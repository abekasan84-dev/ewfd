# ОБУЧЕНИЕ: ночной разбор диалогов -> уроки -> кормим промптам;
# лучшие опенеры победителей становятся few-shot примерами.

import asyncio, json, random
import config, db, llm, health

NIGHT_ANALYZE_TPL = """Ты — аналитик переписок отдела. Вот несколько диалогов.
Найди 3-5 конкретных наблюдений почему люди отвечали или отваливались.
Формат каждой строки: САМО ВЫСКАЗЫВАНИЕ БЕЗ JSON, применяемость.
Верни СТРОГО json: [{{"insight":"...","applies_to":"first_touch|rapport|peer_talk|value_drop|ask_meeting|opener|all","score":1-10}}]
Диалоги: {data}"""

async def collect_yesterday_dialogs(limit=25):
    ids = await db.q(
        "SELECT DISTINCT peer_id FROM msgs WHERE DATE(ts)=DATE('now','localtime','-1 day')",
        fetch="all")
    out = []
    for (pid,) in ids[:limit]:
        h = await db.history(pid, 10)
        st = await db.q("SELECT status,replies FROM leads WHERE peer_id=?",(pid,),"one")
        if h:
            out.append({"lead_status":st[0],"replies":st[1],"msgs":
                        [(m["role"],m["content"]) for m in h]})
    return out

async def analyze(data:list) -> int:
    if not data: return 0
    resp = await llm.think([
        {"role":"system","content":NIGHT_ANALYZE_TPL.format(
            data=json.dumps(data[:limit_sample()], ensure_ascii=False)[:6000])},
        {"role":"user","content":"Проанализируй"}], temp=0.3, pres=0.1)
    arr = json.loads(resp.strip().strip("`").removeprefix("json"))
    n = 0
    for item in arr[:5]:
        ins = str(item.get("insight",""))[:200]
        if ins:
            await db.add_lesson(ins, item.get("applies_to","all"),
                                float(item.get("score",5)), "ai")
            n += 1
    await db.prune_lessons(keep_top=40)
    return n

def limit_sample():
    return 12

async def nightly(now):
    data = await collect_yesterday_dialogs()
    added = await health.guarded("night-analyze", analyze(data))
    fs = await db.best_openers(min_sent=1, k=config.OPENER_FEWSHOT)
    msg = (f"🌙 Ночной разбор: диалогов {len(data)}, добавлено уроков: "
           f"{added if added is not None else 'err'}\nТоп-опенеры:\n" +
           ("\n---\n".join(fs) if fs else "пока нет статистики"))
    return msg

async def teach_rule(text:str):
    """Мгновенное правило от владельца — становится активным уроком."""
    await db.add_lesson(text, "all", 10.0, "user")