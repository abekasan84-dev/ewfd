@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\activate (
  echo Сначала запусти install.bat
  pause
  exit /b 1
)
call .venv\Scripts\activate
python main.py
pause
