# Grok: разведка X/Twitter-профиля лида -> досье.

import json
from openai import AsyncOpenAI
import config, health

xai = AsyncOpenAI(api_key=config.XAI_API_KEY, base_url="https://api.x.ai/v1")

TPL = """Ты читаешь X-аккаунт @{h} для одного предложения: оплачиваемый обзор телефона, сообщество, амбассадорство или интеграция.
Связь с работой есть, если у человека есть аудитория, сообщество, контент, обзоры или партнёрства. Крипто-тематика сама по себе связь не отменяет.
Связи нет только если аккаунт про частную жизнь и из постов не видно ни аудитории, ни контента.
Не бери сплетни, внешность и травлю. Не записывай его профессию в avoid.
Верни СТРОГО json без markdown:
{{"name":"имя или пусто",
"language":"en|ru|zh|tr|other",
"who":"аудитория или роль, одно предложение",
"voice":"как пишет",
"proof":"один конкретный результат: цифра, название его площадки, инструмент или то, что он уже сделал для аудитории",
"quote":"его слова, 40-140 символов",
"work_link":"что именно в его работе можно похвалить и почему с ним хорошо сработаться. Не оценка вроде work you do. Пусто, если факта нет",
"avoid":["только сплетни и лишнее"]}}
Если связь есть, work_link не оставляй пустым."""

def _loads(txt: str) -> dict:
    raw = (txt or "").strip()
    if "```" in raw:
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]
    start, end = raw.find("{"), raw.rfind("}")
    if start < 0 or end <= start:
        raise ValueError("no json")
    data = json.loads(raw[start:end + 1])
    if not isinstance(data, dict):
        raise ValueError("not an object")
    return data

def _thin(d: dict) -> bool:
    if "work_link" not in d:
        return True
    return len((d.get("who") or "").strip()) < 12

async def _ask(h: str, extra: str) -> dict:
    resp = await xai.responses.create(
        model=config.XAI_MODEL,
        input=[{"role": "system", "content": TPL.format(h=h)},
               {"role": "user", "content": extra}],
        tools=[{"type": "x_search", "allowed_x_handles": [h], "max_turns": 4}])
    return _loads(resp.output_text)

async def analyze(handle: str) -> dict:
    h = handle.lstrip("@")
    data = await _ask(h, f"У @{h} найди аудиторию, контент или сообщество. Это и есть связь с оплачиваемым обзором или амбассадорством. work_link заполни, если это есть.")
    if _thin(data):
        try:
            second = await _ask(h, "Прошлый раз связи с работой не было или досье пустое. Найди один профессиональный пост. Если его нет, верни пустой work_link.")
            for key, value in second.items():
                if value or key == "work_link":
                    data[key] = value
        except Exception:
            pass
    data.setdefault("work_link", "")
    return data

import datetime as _dt
async def enrich_if_stale(dbm, peer: int, lead: dict):
    h = (lead or {}).get("x_handle")
    if not h:
        return
    current = await dbm.get_dossier(peer)
    if "work_link" in current and (current.get("who") or current.get("quote")):
        ea = lead.get("enriched_at")
        if ea:
            try:
                old = _dt.datetime.fromisoformat(str(ea).replace(" ", "T"))
                if (_dt.datetime.now() - old).days < config.ENRICH_TTL_D:
                    return
            except Exception:
                pass
    try:
        await health.guarded("grok", _do_save(dbm, peer, h))
    except Exception:
        pass

async def _do_save(dbm, peer, h):
    d = await analyze(h)
    merged = await dbm.get_dossier(peer)
    for key, value in d.items():
        if value or key not in merged:
            merged[key] = value
    await dbm.save_dossier(peer, merged)
