#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if command -v python3 >/dev/null 2>&1; then
  PY=python3
else
  PY=python
fi

"$PY" - <<'PY'
import sys
if sys.version_info < (3, 10):
    raise SystemExit("Нужен Python 3.10 или новее. Сейчас: " + sys.version)
PY

"$PY" -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt

if [ ! -f .env ]; then
  cp .env.example .env
  echo
  echo "Создан файл .env"
  echo "Открой его, вставь ключи Telegram и DeepSeek, потом снова запусти: ./install.sh"
  exit 0
fi

python - <<'PY'
import os
from dotenv import load_dotenv
load_dotenv()
need = {
    "TG_API_ID": os.getenv("TG_API_ID", ""),
    "TG_API_HASH": os.getenv("TG_API_HASH", ""),
    "TG_PHONE": os.getenv("TG_PHONE", ""),
    "DEEPSEEK_API_KEY": os.getenv("DEEPSEEK_API_KEY", ""),
}
bad = []
for k, v in need.items():
    if not v or "XXXX" in v or "xxxxxxxx" in v or v in {"12345678", "abcdef0123456789abcdef0123456789"}:
        bad.append(k)
if bad:
    raise SystemExit("В .env ещё пример, а не настоящие ключи: " + ", ".join(bad))
print("Ключи на месте. Сейчас откроется вход в Telegram — код придёт в приложение.")
PY

exec python main.py
