import os
from dotenv import load_dotenv

load_dotenv()

API_ID        = int(os.getenv("TG_API_ID", "0"))
API_HASH      = os.getenv("TG_API_HASH", "")
PHONE         = os.getenv("TG_PHONE", "")

DS_API_KEY    = os.getenv("DEEPSEEK_API_KEY", "")
XAI_API_KEY   = os.getenv("XAI_API_KEY", "")

DIALOG_MODEL  = os.getenv("DIALOG_MODEL", "deepseek-v4-pro")
HARD_MODEL    = os.getenv("HARD_MODEL", "deepseek-v4-pro")
XAI_MODEL     = os.getenv("XAI_MODEL", "grok-4")

NEW_EVERY_MIN = int(os.getenv("NEW_CONTACT_EVERY_MIN", "30"))
JITTER_SEC    = int(os.getenv("JITTER_SEC", "180"))
WH_START, WH_END = (int(x) for x in os.getenv("WORK_HOURS", "9-23").split("-"))
DAILY_CAP     = int(os.getenv("DAILY_CAP", "40"))
ENRICH_TTL_D  = int(os.getenv("ENRICH_TTL_DAYS", "7"))

LEARN_HOUR    = int(os.getenv("LEARN_HOUR", "3"))
DIGEST_HOUR   = int(os.getenv("DIGEST_HOUR", "9"))
OPENER_FEWSHOT= int(os.getenv("OPENER_FEWSHOT", "3"))
LESSONS_TOP   = int(os.getenv("LESSONS_TOP", "5"))
FLOOD_CD_MIN  = int(os.getenv("FLOOD_COOLDOWN_MIN", "120"))

QUEUE_FILE    = os.getenv("QUEUE_FILE", "queue.txt")
DB_PATH       = os.getenv("DB_PATH", "bot.db")

MY_NAME       = os.getenv("MY_NAME", "Алекс")
PRODUCT_DESC  = os.getenv("PRODUCT_DESC", "")
FIRST_DELAY   = int(os.getenv("FIRST_DELAY_SEC", "20"))

def missing_keys():
    bad = []
    if not API_ID:
        bad.append("TG_API_ID")
    if not API_HASH or "abcdef" in API_HASH:
        bad.append("TG_API_HASH")
    if not PHONE or "XXXX" in PHONE:
        bad.append("TG_PHONE")
    if not DS_API_KEY or DS_API_KEY.startswith("sk-xxxx"):
        bad.append("DEEPSEEK_API_KEY")
    return bad