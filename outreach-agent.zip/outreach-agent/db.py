# Всё состояние: лиды, досье, история, ролли, миссии, уроки, KPI, ошибки.

import aiosqlite, json, datetime as dt
import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS leads(
  peer_id       INTEGER PRIMARY KEY,
  handle        TEXT,
  x_handle      TEXT,
  status        TEXT DEFAULT 'queued', -- queued|contacted|talking|hot|refused|dead
  stage         TEXT DEFAULT 'none',
  replies       INTEGER DEFAULT 0,
  opener_id     INTEGER,
  role          TEXT DEFAULT 'auto',
  first_touch   TIMESTAMP,
  last_activity TIMESTAMP,
  enriched_at   TIMESTAMP,
  dossier       TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS msgs(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  peer_id INTEGER, role TEXT, text TEXT,
  ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS counters(
  day TEXT PRIMARY KEY, sent INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS kpi(
  day TEXT PRIMARY KEY, newc INTEGER DEFAULT 0, replies INTEGER DEFAULT 0,
  hot INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS openers(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  text TEXT UNIQUE, sent INTEGER DEFAULT 0, replied INTEGER DEFAULT 0,
  ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS missions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT, metric TEXT, target REAL, deadline TEXT,
  tasks TEXT DEFAULT '[]',       -- json [{d,done}]
  status TEXT DEFAULT 'active',  -- active|done|cancelled
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS lessons(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  insight TEXT, applies_to TEXT DEFAULT 'all',
  score REAL DEFAULT 5.0, source TEXT DEFAULT 'ai', -- ai|user
  active INTEGER DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS asks(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  peer_id INTEGER,
  handle TEXT,
  question TEXT,
  their_text TEXT,
  msg_id INTEGER,
  answer TEXT,
  status TEXT DEFAULT 'open',
  ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS errorlog(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  kind TEXT, ts TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

def _now():
    return dt.datetime.now()

def _day(n=0):
    return (dt.date.today() - dt.timedelta(days=n)).isoformat()

async def _c():
    return aiosqlite.connect(config.DB_PATH)

# ---------- ядро ----------
async def add_ask(peer, handle, question, their_text, msg_id):
    await q("INSERT INTO asks(peer_id, handle, question, their_text, msg_id) VALUES(?,?,?,?,?)",
            (peer, handle, question, their_text[:400], msg_id))

async def open_ask_for(peer):
    return await q("SELECT id FROM asks WHERE peer_id=? AND status='open' ORDER BY id DESC LIMIT 1",
                   (peer,), "one")

async def latest_open_ask():
    return await q("SELECT id, peer_id, handle, question FROM asks WHERE status='open' ORDER BY id DESC LIMIT 1",
                   (), "one")

async def ask_by_msg(msg_id):
    return await q("SELECT id, peer_id, handle, question FROM asks WHERE msg_id=? AND status='open'",
                   (msg_id,), "one")

async def close_ask(ask_id, answer):
    await q("UPDATE asks SET status='closed', answer=? WHERE id=?", (answer[:500], ask_id))

async def init():
    async with await _c() as c:
        await c.executescript(SCHEMA)
        await c.executescript("""
        CREATE UNIQUE INDEX IF NOT EXISTS idx_leads_handle ON leads(handle);
        CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);
        CREATE INDEX IF NOT EXISTS idx_msgs_peer ON msgs(peer_id);
        """)
        await c.commit()

def _clean(h) -> str:
    s = str(h or "").strip().lstrip("@")
    if s.isdigit():
        return s
    return s.lower()

async def ensure_queued(tg, xh=""):
    handle = _clean(tg)
    xh_clean = _clean(xh)
    if not handle:
        return None
    row = await q("SELECT peer_id, x_handle FROM leads WHERE handle=?", (handle,), "one")
    if row:
        if xh_clean and not row[1]:
            await q("UPDATE leads SET x_handle=? WHERE peer_id=?", (xh_clean, row[0]))
        return row[0]
    return await q("INSERT INTO leads(handle, x_handle) VALUES(?, ?)", (handle, xh_clean))

async def rebind_peer(old_id: int, new_id: int) -> int:
    """Подменяет временный id строки на настоящий Telegram user id."""
    old_id, new_id = int(old_id), int(new_id)
    if old_id == new_id:
        return new_id
    async with await _c() as c:
        cur = await c.execute("SELECT 1 FROM leads WHERE peer_id=?", (new_id,))
        clash = await cur.fetchone()
        await c.execute("UPDATE msgs SET peer_id=? WHERE peer_id=?", (new_id, old_id))
        if clash:
            await c.execute("DELETE FROM leads WHERE peer_id=?", (old_id,))
        else:
            await c.execute("UPDATE leads SET peer_id=? WHERE peer_id=?", (new_id, old_id))
        await c.commit()
    return new_id

async def q(sql, args=(), fetch=None):
    """Один вход для запросов; fetch='one'|'all'."""
    async with await _c() as c:
        cur = await c.execute(sql, args)
        if fetch == "one":
            r = await cur.fetchone()
        elif fetch == "all":
            r = await cur.fetchall()
        else:
            r = cur.lastrowid
        await c.commit()
        return r

async def next_queued(exclude=()):
    exclude = [int(x) for x in exclude]
    if exclude:
        marks = ",".join("?" * len(exclude))
        sql = ("SELECT peer_id,handle,x_handle FROM leads WHERE status='queued' "
               f"AND peer_id NOT IN ({marks}) ORDER BY "
               "CASE WHEN dossier LIKE '%\"batch\": \"b5\"%' THEN 0 ELSE 1 END, peer_id LIMIT 1")
        r = await q(sql, tuple(exclude), "one")
    else:
        r = await q("SELECT peer_id,handle,x_handle FROM leads WHERE status='queued' "
                    "ORDER BY CASE WHEN dossier LIKE '%\"batch\": \"b5\"%' THEN 0 ELSE 1 END, peer_id LIMIT 1",
                    fetch="one")
    return {"peer_id": r[0], "handle": r[1], "x_handle": r[2]} if r else None

async def set_status(p, s): await q("UPDATE leads SET status=? WHERE peer_id=?", (s,p))
async def mark_first_touch(p):
    await q("UPDATE leads SET status='contacted',first_touch=CURRENT_TIMESTAMP "
            "WHERE peer_id=?", (p,))
async def touch(p):
    await q("UPDATE leads SET status='talking',replies=replies+1,"
            "last_activity=CURRENT_TIMESTAMP WHERE peer_id=?", (p,))
async def set_stage(p,s): await q("UPDATE leads SET stage=? WHERE peer_id=?", (s,p))
async def set_role(p,r):   await q("UPDATE leads SET role=? WHERE peer_id=?", (r,p))
async def get_role(p):
    r = await q("SELECT role FROM leads WHERE peer_id=?", (p,), "one")
    return r[0] if r else "auto"
async def set_opener(p, oid): await q("UPDATE leads SET opener_id=? WHERE peer_id=?", (oid,p))

async def get_lead(p):
    r = await q("SELECT * FROM leads WHERE peer_id=?", (p,), "one")
    if not r: return None
    cols = ["peer_id","handle","x_handle","status","stage","replies","opener_id",
            "role","first_touch","last_activity","enriched_at","dossier"]
    d = dict(zip(cols, r))
    try: d["dossier"] = json.loads(d.get("dossier") or "{}")
    except Exception: d["dossier"] = {}
    return d

async def get_dossier(p):
    l = await get_lead(p)
    return (l or {}).get("dossier", {})

async def save_dossier(p, doss):
    await q("UPDATE leads SET dossier=?,enriched_at=CURRENT_TIMESTAMP "
            "WHERE peer_id=?", (json.dumps(doss, ensure_ascii=False), p))

async def add_promise(p, text):
    d = await get_dossier(p)
    d.setdefault("promises", []).append(text[:200])
    await q("UPDATE leads SET dossier=? WHERE peer_id=?",
            (json.dumps(d, ensure_ascii=False), p))

async def log(p, role, text):
    await q("INSERT INTO msgs(peer_id,role,text) VALUES(?,?,?)", (p, role, text))

async def history(p, n=24):
    rows = await q("SELECT role,text FROM msgs WHERE peer_id=? ORDER BY id DESC "
                   "LIMIT ?", (p, n), "all")
    rows.reverse()
    return [{"role":"user" if r[0]=="user" else "assistant","content":r[1]} for r in rows]

async def talk_days(p):
    r = await q("SELECT COUNT(DISTINCT DATE(ts)) FROM msgs WHERE peer_id=?",
                (p,), "one")
    return r[0] if r else 0

# ---------- счётчики/KPI ----------
async def bump_daily(day):
    await q("INSERT INTO counters(day,sent) VALUES(?,1) "
            "ON CONFLICT(day) DO UPDATE SET sent=sent+1", (day,))
async def today_count(day):
    r = await q("SELECT sent FROM counters WHERE day=?", (day,), "one")
    return r[0] if r else 0

_KPI_FIELDS = {"newc", "replies", "hot"}

async def kpi_bump(field):  # 'newc'|'replies'|'hot'
    if field not in _KPI_FIELDS:
        raise ValueError(f"bad kpi field: {field}")
    d = _day()
    await q(f"INSERT INTO kpi(day,{field}) VALUES(?,1) "
            f"ON CONFLICT(day) DO UPDATE SET {field}={field}+1", (d,))

async def kpi_sum(field, days_back=1):
    if field not in _KPI_FIELDS:
        raise ValueError(f"bad kpi field: {field}")
    r = await q(f"SELECT SUM({field}) FROM kpi WHERE day<=?", (_day(),), "one")
    return r[0] or 0

# ---------- опенеры (A/B самообучение) ----------
async def remember_opener(text):
    await q("INSERT OR IGNORE INTO openers(text) VALUES(?)", (text,))
    r = await q("SELECT id FROM openers WHERE text=?", (text,), "one")
    return r[0]

async def opener_hit(oid):
    if oid:
        await q("UPDATE openers SET replied=replied+1 WHERE id=?", (oid,))

async def opener_mark_sent(oid):
    if oid:
        await q("UPDATE openers SET sent=sent+1 WHERE id=?", (oid,))

async def recent_openers(n=15):
    return [r[0] for r in await q(
        "SELECT text FROM openers ORDER BY id DESC LIMIT ?", (n,), "all")]

async def best_openers(min_sent=3, k=3):
    rows = await q("SELECT text FROM openers WHERE sent>=? AND replied>0 "
                   "ORDER BY (CAST(replied AS FLOAT)/sent) DESC LIMIT ?",
                   (min_sent, k), "all")
    return [r[0] for r in rows]

# ---------- уроки ----------
async def add_lesson(insight, applies_to="all", score=5.0, source="ai"):
    dup = await q("SELECT id FROM lessons WHERE insight=? LIMIT 1",
                  (insight.strip()[:200],), "one")
    if dup: return
    await q("INSERT INTO lessons(insight,applies_to,score,source) VALUES(?,?,?,?)",
            (insight.strip()[:200], applies_to, score, source))

async def prune_lessons(keep_top=40):
    await q("""DELETE FROM lessons WHERE id NOT IN (
                 SELECT id FROM lessons ORDER BY score DESC LIMIT ?)""", (keep_top,))
    await q("UPDATE lessons SET active=active WHERE id IN "
            "(SELECT id FROM lessons ORDER BY score DESC LIMIT ?)", (keep_top,))

async def active_lessons(applies_like, k=5):
    rows = await q("SELECT insight FROM lessons WHERE active=1 AND "
                   "(applies_to=? OR applies_to='all') ORDER BY score DESC LIMIT ?",
                   (applies_like, k), "all")
    return [r[0] for r in rows]

async def lessons_of_source(source, since_day_ago=1):
    rows = await q("SELECT insight FROM lessons WHERE source=? AND "
                   "created_at > datetime('now','localtime','-1 day')",
                   (source,), "all")
    return [r[0] for r in rows]

# ---------- миссии ----------
async def mission_add(title, metric, target, deadline, tasks_json):
    return await q("INSERT INTO missions(title,metric,target,deadline,tasks) "
                   "VALUES(?,?,?,?,?)", (title, metric, target, deadline, tasks_json))

async def missions_active():
    return await q("SELECT * FROM missions WHERE status='active' ORDER BY id",
                   fetch="all")

async def mission_set_task(mid, idx, done=True):
    r = await q("SELECT tasks FROM missions WHERE id=?", (mid,), "one")
    if not r: return
    arr = json.loads(r[0] or "[]")
    if 0 <= idx < len(arr):
        arr[idx]["done"] = bool(done)
        await q("UPDATE missions SET tasks=? WHERE id=?",
                (json.dumps(arr, ensure_ascii=False), mid))

async def mission_close(mid, status="done"):
    await q("UPDATE missions SET status=? WHERE id=?", (status, mid))

# ---------- ошибки ----------
async def errlog(kind):
    await q("INSERT INTO errorlog(kind) VALUES(?)", (kind,))

async def errors_today():
    r = await q("SELECT COUNT(*) FROM errorlog WHERE "
                "DATE(ts)=DATE('now','localtime')", fetch="one")
    return r[0] if r else 0

# ---------- сводка ----------
async def stats_str():
    out = []
    for st in ("queued","contacted","talking","hot","refused","dead"):
        r = await q("SELECT COUNT(*) FROM leads WHERE status=?", (st,), "one")
        out.append(f"{st}: {r[0]}")
    out.append(f"sent_today: {await today_count(_day())}")
    out.append(f"errors_today: {await errors_today()}")
    n = await q("SELECT COUNT(*) FROM missions WHERE status='active'", fetch="one")
    l = await q("SELECT COUNT(*) FROM lessons WHERE active=1", fetch="one")
    out.append(f"missions_active: {n[0]} | lessons: {l[0]}")
    return "\n".join(out)